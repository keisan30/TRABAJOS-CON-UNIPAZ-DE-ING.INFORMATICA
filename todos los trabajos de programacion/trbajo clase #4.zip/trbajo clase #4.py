dicc = {
    "nomres":"Keiner Yesid",
    "apellidos":"Quevedo Rivera",
    "Edad":"",
    "Equipo de fut fav":"Barcelona"
}
Edad= input("ingrese la Edad")
dicc["Edad"]=Edad

Ti= input("ingrese la Ti ")
dicc["Ti"]=Ti
print(dicc)