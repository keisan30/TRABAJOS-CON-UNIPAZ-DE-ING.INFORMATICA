usuarios = {
    "pinzon": "nomber1",
    "andres": "dulce2025",
    "admin": "ayer099"
}

historial = []

roles = ("Invitado", "Usuario", "Administrador")

print("=== SISTEMA DE LOGIN ===")

usuario = input("Usuario: ")
clave = input("Contraseña: ")

if usuario in usuarios:
    if usuarios[usuario] == clave:
       
        historial.append((usuario, "Éxito")) 
       
        if usuario == "admin":
            rol = roles[2]
        else:
            rol = roles[1]
        print(f" Bienvenido {usuario} - Rol: {rol}")
    else:
        historial.append((usuario, "Contraseña incorrecta"))
        print(" Contraseña incorrecta.")
else:
    historial.append((usuario, "Usuario no encontrado"))
    print("Usuario no encontrado.")

print("\n Historial de accesos:")
for registro in historial:
  print(registro)