#una funcion en python que me permitan sumar restar multiplicar o didvidir 2numeros y que se pongan como funcion
    #Calculadora de temperatura( Convertir de temperatura)

#1)
#Definicion
def resta(a, b):
    print(a-b)
def suma(a, b):
    print(a+b)
def dividir(a, b):
    print(a/b)
def multiplicar(a, b):
    print(a*b)
#las variables
menu = True
while menu == True:
    print("=======Lista de opciones======")
    print(                 "1. Suma")
    print(                 "2. Resta")
    print(                 "3. Multiplicacion")
    print(                 "4. dividir")
    print('Oprima 5 para salir.')
    opciones= int(input( " Elija una opcion (1-5): "))
    if opciones == 1:
        a = float(input("Ingrese el PRIMER Numero :"))
        b = float(input("Ingrese el SEGUNDO Numero :"))
        suma(a, b)
    elif opciones == 2:
        a = float(input("Ingrese el PRIMER Numero :"))
        b = float(input("Ingrese el SEGUNDO Numero :"))
        resta(a, b)
    elif opciones == 3:
        a = float(input("Ingrese el PRIMER Numero :"))
        b = float(input("Ingrese el SEGUNDO Numero :"))
        multiplicar(a, b)
    elif opciones == 4:
        a = float(input("Ingrese el PRIMER Numero :"))
        b = float(input("Ingrese el SEGUNDO Numero :"))
        dividir(a, b)
    elif opciones == 5:
        print('Gracias por usar')
        menu == False
        break
    else:
        print("La opcion no es valida, Intente denuevo porfavor")

        #el menu

