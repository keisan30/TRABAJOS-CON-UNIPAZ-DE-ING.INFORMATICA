#calculadora de temperatura
def celsius_a_fahrenheit(c):
    return (c * 9/5) + 32

def fahrenheit_a_celsius(f):
    return (f - 32) * 5/9

def celsius_a_kelvin(c):
    return c + 273.15

def kelvin_a_celsius(k):
    return k - 273.15

def fahrenheit_a_kelvin(f):
    return (f - 32) * 5/9 + 273.15

def kelvin_a_fahrenheit(k):
    return (k - 273.15) * 9/5 + 32

menu = True
while menu == True:
    print("=== Calculadora de Temperatura ===")
    print("1. Celsius a Fahrenheit")
    print("2. Fahrenheit a Celsius")
    print("3. Celsius a Kelvin")
    print("4. Kelvin a Celsius")
    print("5. Fahrenheit a Kelvin")
    print("6. Kelvin a Fahrenheit")
    print('7. Salir del programa')

    op = int(input("Elige una opción: "))

    if op == 1:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", celsius_a_fahrenheit(valor), "°F")
    elif op == 2:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", fahrenheit_a_celsius(valor), "°C")
    elif op == 3:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", celsius_a_kelvin(valor), "K")
    elif op == 4:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", kelvin_a_celsius(valor), "°C")
    elif op == 5:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", fahrenheit_a_kelvin(valor), "K")
    elif op == 6:
        valor = float(input("Ingresa el valor de temperatura: "))
        print("Resultado:", kelvin_a_fahrenheit(valor), "°F")
    elif op == 7:
        print('\n Gracias por usar\n')
        menu = False
    else:
        print("\nOpción no válida\n")
