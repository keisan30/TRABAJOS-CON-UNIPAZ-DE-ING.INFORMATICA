lista_resultados = []

def suma(textbox1, textbox2, label):
    global lista_resultados
    
    num1 = int(textbox1.get())
    num2 = int(textbox2.get())
    sum = num1 + num2

    lista_resultados.append(sum)
    label.configure(text=str(sum))


def resta(textbox1, textbox2, label):
    global lista_resultados
    
    num1 = int(textbox1.get())
    num2 = int(textbox2.get())
    rest = num1 - num2

    lista_resultados.append(rest)
    label.configure(text=str(rest))


def historial(label2):
    listt = " - ".join(str(x) for x in lista_resultados)
    label2.configure(text=listt)
    
