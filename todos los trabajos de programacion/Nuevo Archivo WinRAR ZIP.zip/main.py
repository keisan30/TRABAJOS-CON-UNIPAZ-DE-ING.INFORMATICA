import tkinter as tk
from backend import suma, resta, historial

root = tk.Tk()
root.title("windows")
root.geometry("400x400")
root.config(background="green")

textbox1 = tk.Entry(root, width=20)
textbox1.grid(row=0, column=0, padx=5, pady=10)

textbox2 = tk.Entry(root, width=20)
textbox2.grid(row=0, column=1, padx=5, pady=10)

label = tk.Label(root, text="")
label.grid(row=1, column=0, padx=2, pady=5)

btn1 = tk.Button(root, text="suma", command=lambda: suma(textbox1, textbox2, label))
btn1.grid(row=1, column=1, columnspan=2, pady=10)

btn2 = tk.Button(root, text="resta", command=lambda: resta(textbox1, textbox2, label))
btn2.grid(row=2, column=1, columnspan=2, pady=5)

label2 = tk.Label(root, text="", bg="white", width=40)
label2.grid(row=3, column=0, columnspan=2, pady=10)

btn3 = tk.Button(root, text="historial", command=lambda: historial(label2))
btn3.grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()

