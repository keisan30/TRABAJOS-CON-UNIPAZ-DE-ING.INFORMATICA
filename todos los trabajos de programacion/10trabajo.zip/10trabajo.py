def registrar_usuario(usuarios):

    nombre_usuario = input("Ingresa tu nuevo nombre de usuario: ")

    if nombre_usuario in usuarios:

        print("Este nombre de usuario ya existe. Por favor, elige otro.")

        return

    contraseña = input("Ingresa tu contraseña: ")

    usuarios[nombre_usuario] = contraseña

    print("¡Registro exitoso!")

def iniciar_sesion(usuarios):

    nombre_usuario = input("Nombre de usuario: ")

    contraseña = input("Contraseña: ")

    if nombre_usuario in usuarios and usuarios[nombre_usuario] == contraseña:

        print("¡Inicio de sesión exitoso!")

        return True

    else:

        print("Nombre de usuario o contraseña incorrectos.")

        return False

def main():



    usuarios = {} 

    while True:

        print("\n--- Menú ---")

        print("1. Iniciar sesión")

        print("2. Registrarse")

        print("3. Salir")

        opcion = input("Elige una opción: ")

        if opcion == '1':

            if iniciar_sesion(usuarios):

                print("¡Bienvenido!")

                break  

        elif opcion == '2':

            registrar_usuario(usuarios)

        elif opcion == '3':

            print("¡Hasta luego!")

            break

        else:

            print("Opción no válida. Por favor, elige una opción del menú.")


if __name__== "__main__":

    main()