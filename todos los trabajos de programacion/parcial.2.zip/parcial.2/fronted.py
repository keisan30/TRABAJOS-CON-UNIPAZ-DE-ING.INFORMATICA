import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from backend import ControlInventario


class VentanaInventario:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Sistema de Inventario")
        self.ventana.geometry("540x760")
        self.ventana.resizable(True, True)

        
        canvas = tk.Canvas(ventana)
        barra = tk.Scrollbar(ventana, orient="vertical", command=canvas.yview)
        barra.pack(side="right", fill="y")

        contenedor = tk.Frame(canvas)
        contenedor.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=contenedor, anchor="nw")
        canvas.configure(yscrollcommand=barra.set)
        canvas.pack(fill="both", expand=True)

       
        self.inventario = ControlInventario()
        self.carrito = []  

        marco_registro = tk.LabelFrame(contenedor, text="Registro de Productos", padx=10, pady=10)
        marco_registro.pack(fill="x", padx=10, pady=5)

        tk.Label(marco_registro, text="Código:").grid(row=0, column=0, sticky="w")
        self.codigo_input = tk.Entry(marco_registro)
        self.codigo_input.grid(row=1, column=0, sticky="we", pady=3)

        tk.Label(marco_registro, text="Nombre:").grid(row=2, column=0, sticky="w")
        self.nombre_input = tk.Entry(marco_registro)
        self.nombre_input.grid(row=3, column=0, sticky="we", pady=3)

        tk.Label(marco_registro, text="Categoría:").grid(row=4, column=0, sticky="w")
        self.categoria_cb = ttk.Combobox(marco_registro, values=self.inventario.categorias)
        self.categoria_cb.grid(row=5, column=0, sticky="we", pady=3)

        tk.Label(marco_registro, text="Cantidad:").grid(row=6, column=0, sticky="w")
        self.cantidad_input = tk.Entry(marco_registro)
        self.cantidad_input.grid(row=7, column=0, sticky="we", pady=3)

        tk.Label(marco_registro, text="Precio:").grid(row=8, column=0, sticky="w")
        self.precio_input = tk.Entry(marco_registro)
        self.precio_input.grid(row=9, column=0, sticky="we", pady=3)

        # Botones principales
        tk.Button(marco_registro, text="Registrar", command=self.agregar_producto).grid(row=10, column=0, pady=5, sticky="we")
        tk.Button(marco_registro, text="Editar", command=self.modificar_producto).grid(row=11, column=0, pady=5, sticky="we")
        tk.Button(marco_registro, text="Nueva Categoría", command=self.nueva_categoria).grid(row=12, column=0, pady=5, sticky="we")

       
        self.tabla = ttk.Treeview(contenedor, columns=("Codigo", "Nombre", "Categoria", "Cantidad", "Precio"), show="headings")
        for col in ("Codigo", "Nombre", "Categoria", "Cantidad", "Precio"):
            self.tabla.heading(col, text=col)
        self.tabla.pack(fill="x", padx=10, pady=10)

        marco_factura = tk.LabelFrame(contenedor, text="Factura de Compra", padx=10, pady=10)
        marco_factura.pack(fill="x", padx=10, pady=5)

        tk.Label(marco_factura, text="Código del producto:").grid(row=0, column=0)
        tk.Label(marco_factura, text="Cantidad:").grid(row=0, column=1)
        self.codigo_factura = tk.Entry(marco_factura)
        self.cantidad_factura = tk.Entry(marco_factura)
        self.codigo_factura.grid(row=1, column=0)
        self.cantidad_factura.grid(row=1, column=1)

        tk.Button(marco_factura, text="Agregar a la factura", command=self.agregar_a_factura).grid(row=1, column=2)
        tk.Button(marco_factura, text="Finalizar Compra", command=self.finalizar_factura).grid(row=2, column=0, columnspan=3, pady=5)

        self.texto_factura = tk.Text(marco_factura, height=14, width=70)
        self.texto_factura.grid(row=3, column=0, columnspan=3, pady=5)

   
    def agregar_producto(self):
        """Guarda un nuevo producto en el inventario"""
        datos = (
            self.codigo_input.get(),
            self.nombre_input.get(),
            self.categoria_cb.get(),
            self.cantidad_input.get(),
            self.precio_input.get()
        )

        if all(datos):
            if self.inventario.agregar_producto(*datos):
                self.actualizar_tabla()
                messagebox.showinfo("Éxito", "Producto guardado correctamente.")
            else:
                messagebox.showerror("Error", "Ese código ya está registrado.")
        else:
            messagebox.showwarning("Aviso", "Complete todos los campos antes de registrar.")

    def modificar_producto(self):
        """Permite editar la información de un producto existente"""
        codigo = self.codigo_input.get()
        if codigo:
            modificado = self.inventario.modificar_producto(
                codigo,
                nombre=self.nombre_input.get() or None,
                categoria=self.categoria_cb.get() or None,
                cantidad=self.cantidad_input.get() or None,
                precio=self.precio_input.get() or None
            )
            if modificado:
                self.actualizar_tabla()
                messagebox.showinfo("Éxito", "Producto actualizado correctamente.")
            else:
                messagebox.showerror("Error", "No se encontró el producto que indicó.")
        else:
            messagebox.showwarning("Aviso", "Debe escribir el código del producto a modificar.")

    def nueva_categoria(self):
        """Crea una nueva categoría para organizar los productos"""
        nueva = simpledialog.askstring("Nueva Categoría", "Ingrese el nombre de la nueva categoría:")
        if nueva:
            if self.inventario.nueva_categoria(nueva):
                self.categoria_cb["values"] = self.inventario.categorias
                messagebox.showinfo("Éxito", "Categoría agregada correctamente.")
            else:
                messagebox.showwarning("Aviso", "Esa categoría ya existe.")

    def agregar_a_factura(self):
        """Agrega un producto a la factura actual"""
        try:
            codigo = self.codigo_factura.get()
            cantidad = int(self.cantidad_factura.get())
            factura = self.inventario.crear_factura(codigo, cantidad)
            if "Error" in factura:
                messagebox.showerror("Error", factura["Error"])
            else:
               
                self.carrito.append(factura)
                self.mostrar_factura_parcial()
                self.actualizar_tabla()
                messagebox.showinfo("Éxito", "Producto agregado a la factura.")
        except ValueError:
            messagebox.showerror("Error", "Ingrese una cantidad válida.")

    def mostrar_factura_parcial(self):
        """Muestra los productos que ya se agregaron a la factura"""
        self.texto_factura.delete(1.0, tk.END)
        self.texto_factura.insert(tk.END, "FACTURA EN PROCESO\n\n")
        total = 0
        for item in self.carrito:
            self.texto_factura.insert(tk.END, f"- {item['Producto']} x{item['Cantidad Vendida']}  ${item['Total']}\n")
            total += item['Total']
        self.texto_factura.insert(tk.END, f"\nTotal parcial: ${total}\n")

    def finalizar_factura(self):
        """Finaliza la factura y muestra el total general"""
        if not self.carrito:
            messagebox.showwarning("Aviso", "No hay productos en la factura.")
            return

        total_final = sum(item['Total'] for item in self.carrito)
        self.texto_factura.insert(tk.END, "\n==============================\n")
        self.texto_factura.insert(tk.END, f"TOTAL FINAL DE LA COMPRA: ${total_final}\n")
        self.texto_factura.insert(tk.END, "==============================\n\n")
        messagebox.showinfo("Compra finalizada", "Factura generada correctamente.")
        self.carrito.clear()

    def actualizar_tabla(self):
        """Actualiza la tabla con los productos actuales"""
        for fila in self.tabla.get_children():
            self.tabla.delete(fila)
        for p in self.inventario.productos:
            self.tabla.insert("", "end", values=(p["Codigo"], p["Nombre"], p["Categoria"], p["Cantidad"], p["Precio"]))


if __name__ == "__main__":
    ventana = tk.Tk()
    app = VentanaInventario(ventana)
    ventana.mainloop()
