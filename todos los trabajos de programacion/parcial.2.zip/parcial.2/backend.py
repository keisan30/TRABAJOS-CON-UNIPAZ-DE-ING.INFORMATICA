class ControlInventario:
    def __init__(self):
        
        self.categorias = ["General"]
        self.productos = []

    
    def nueva_categoria(self, nombre_categoria):
        """Agrega una nueva categoría si no existe"""
        if nombre_categoria not in self.categorias:
            self.categorias.append(nombre_categoria)
            return True
        return False

    
    def agregar_producto(self, codigo, nombre, categoria, cantidad, precio):
        """Registra un producto nuevo en el inventario"""
        for producto in self.productos:
            if producto["Codigo"] == codigo:
                return False 

        try:
            cantidad = int(cantidad)
            precio = float(precio)
        except ValueError:
            return False

        nuevo_producto = {
            "Codigo": codigo,
            "Nombre": nombre,
            "Categoria": categoria,
            "Cantidad": cantidad,
            "Precio": precio
        }
        self.productos.append(nuevo_producto)
        return True

    
    def modificar_producto(self, codigo, nombre=None, categoria=None, cantidad=None, precio=None):
        """Permite modificar los datos de un producto ya existente"""
        for producto in self.productos:
            if producto["Codigo"] == codigo:
                if nombre:
                    producto["Nombre"] = nombre
                if categoria:
                    producto["Categoria"] = categoria
                if cantidad is not None:
                    producto["Cantidad"] = int(cantidad)
                if precio is not None:
                    producto["Precio"] = float(precio)
                return True
        return False

    
    def crear_factura(self, codigo, cantidad_vendida):
        """Genera una factura al realizar una venta"""
        for producto in self.productos:
            if producto["Codigo"] == codigo:
                if producto["Cantidad"] >= cantidad_vendida:
                    total = cantidad_vendida * producto["Precio"]
                    producto["Cantidad"] -= cantidad_vendida
                    factura = {
                        "Producto": producto["Nombre"],
                        "Cantidad Vendida": cantidad_vendida,
                        "Precio Unitario": producto["Precio"],
                        "Total": total
                    }
                    return factura
                else:
                    return {"Error": "No hay suficiente cantidad disponible."}
        return {"Error": "El producto no se encuentra en el inventario."}
